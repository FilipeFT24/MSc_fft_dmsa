To install QuadTools simply open the QuadTools.mltbx file in Matlab.

After installation, command line help for each function can be accessed, for example, by:

>> help quadGaussJacobi

Detailed help files, with examples, for each function are available online at

http://u.osu.edu/kubatko.3/codes_and_software/quadtools/

 

